#!/usr/bin/env bash
# =====================================================================
#  installer_comfy.sh (v4) — zone privée en mémoire vive + ComfyUI + outil « civitai »
#  À lancer au début de chaque session :  bash /root/installer_comfy.sh
#
#  Toutes les données privées (images, entrées, workflows, clés, journal,
#  historique du terminal, fichiers temporaires de ComfyUI) vont dans
#  /root/prive, qui est un LIEN vers /dev/shm/prive : de la mémoire vive,
#  jamais écrite sur le disque. Le script s'ARRÊTE si cette garantie ne
#  peut pas être assurée (pas de tmpfs, zone trop petite, swap possible).
#  Ne supprime aucun fichier contenant des données. Aucun secret.
# =====================================================================
set -euo pipefail

COMFY_VERSION="v0.39.2"
ZONE=/dev/shm/prive

echo "==> 1/6 Zone privée en mémoire vive"
if [ "$(stat -f -c %T /dev/shm 2>/dev/null)" != "tmpfs" ]; then
  echo "ARRÊT : /dev/shm n'est pas une zone en mémoire vive (tmpfs). Rien n'a été installé."; exit 1
fi
LIBRE_MO=$(df -Pm /dev/shm | awk 'NR==2{print $4}')
if [ "${LIBRE_MO:-0}" -lt 1024 ]; then
  echo "ARRÊT : zone en mémoire vive trop petite (${LIBRE_MO} Mo libres, 1024 Mo minimum)."; exit 1
fi
NB_SWAP=$(awk 'NR>1 && NF' /proc/swaps | wc -l)
SWAP_MAX=$(cat /sys/fs/cgroup/memory.swap.max 2>/dev/null || echo "?")
if [ "$NB_SWAP" -gt 0 ] && [ "$SWAP_MAX" != "0" ]; then
  echo "ARRÊT : la machine a une mémoire d'échange (swap) et le Pod peut l'utiliser (limite : $SWAP_MAX)."
  echo "        La mémoire vive pourrait alors être écrite sur un disque. Change de Pod ou de région."; exit 1
fi
if [ -L /root/prive ]; then
  [ "$(readlink -f /root/prive)" = "$ZONE" ] || { echo "ARRÊT : /root/prive pointe vers $(readlink -f /root/prive)"; exit 1; }
elif [ -d /root/prive ]; then
  if [ -n "$(find /root/prive -type f -print -quit)" ]; then
    echo "ARRÊT : /root/prive contient déjà des fichiers SUR LE DISQUE (ancienne version)."
    echo "        Récupère-les puis termine ce Pod ; rien n'a été modifié."; exit 1
  fi
  find /root/prive -depth -type d -empty -delete   # anciens dossiers VIDES uniquement
fi
mkdir -p "$ZONE"/{input,output,temp,tmp,.secrets,user/default/workflows}
chmod 700 "$ZONE" "$ZONE/.secrets"
[ -L /root/prive ] || ln -s "$ZONE" /root/prive
[ -f "$ZONE/.debut_session" ] || touch "$ZONE/.debut_session"
# Jeton Hugging Face : l'emplacement standard devient un lien vers la mémoire vive
mkdir -p /root/.cache/huggingface
if [ -f /root/.cache/huggingface/token ] && [ ! -L /root/.cache/huggingface/token ]; then
  mv /root/.cache/huggingface/token "$ZONE/.secrets/hf_token"
  echo "   (jeton HF trouvé sur le disque : déplacé en mémoire vive)"
fi
ln -sfn "$ZONE/.secrets/hf_token" /root/.cache/huggingface/token
for ancien in /root/.civitai_token:.secrets/civitai_token /root/civitai_journal.txt:.civitai_journal.txt \
              /root/.bash_history:.bash_history /root/mes_modeles_civitai.txt:mes_modeles_civitai.txt; do
  src=${ancien%%:*}; dst=$ZONE/${ancien#*:}
  if [ -f "$src" ] && [ ! -L "$src" ]; then mv "$src" "$dst"; echo "   ($src déplacé en mémoire vive)"; fi
done
# Historique des terminaux en mémoire vive, pas de fichier « core » en cas de plantage
if ! grep -q 'comfy-zone-ram' /root/.bashrc 2>/dev/null; then
  printf '\n# comfy-zone-ram\nexport HISTFILE=/root/prive/.bash_history\nulimit -c 0\n' >> /root/.bashrc
fi
echo "   /root/prive -> $ZONE (mémoire vive, ${LIBRE_MO} Mo libres)"

echo "==> 2/6 ComfyUI ${COMFY_VERSION}"
cd /workspace
if [ ! -d ComfyUI ]; then
  git clone https://github.com/Comfy-Org/ComfyUI.git
fi
cd /workspace/ComfyUI
git fetch --tags --quiet
git -c advice.detachedHead=false checkout "${COMFY_VERSION}"

echo "==> 3/6 Environnement Python (PyTorch verrouillé)"
if [ ! -d /root/venv-comfy ]; then
  python3 -m venv --system-site-packages /root/venv-comfy
fi
# shellcheck disable=SC1091
source /root/venv-comfy/bin/activate
# Les noyaux optimisés de ComfyUI (comfy-kitchen : int8 convrot, nvfp4, fp8, RoPE, RMSNorm…) exigent PyTorch compilé pour
# CUDA 13 ; avec CUDA 12.8, ComfyUI les désactive et tout passe par un calcul de repli, beaucoup plus lent.
# Si l'image du Pod est ancienne (CUDA 12) et que le pilote de la machine accepte CUDA 13 (r580 et plus), PyTorch 2.9.1
# pour CUDA 13.0 est installé dans l'environnement de ComfyUI (paquets publics de pytorch.org, aucun secret).
# Le mieux reste de mettre l'image CUDA 13 dans le modèle Runpod : rien à télécharger à chaque Pod.
TORCH_CUDA=$(python -c "import torch; print(torch.version.cuda or '')" 2>/dev/null || true)
PILOTE_CUDA=$(nvidia-smi 2>/dev/null | grep -o 'CUDA Version: [0-9]*' | grep -o '[0-9]*$' || true)
if [ -n "$TORCH_CUDA" ] && [ "${TORCH_CUDA%%.*}" -lt 13 ] && [ "${PILOTE_CUDA:-0}" -ge 13 ]; then
  echo "   PyTorch pour CUDA $TORCH_CUDA : installation de PyTorch 2.9.1 pour CUDA 13 (noyaux optimisés de ComfyUI)…"
  if pip install --quiet torch==2.9.1 torchvision==0.24.1 torchaudio==2.9.1 --index-url https://download.pytorch.org/whl/cu130; then
    echo "   PyTorch 2.9.1 (CUDA 13) installé. Pour éviter ce téléchargement : image CUDA 13 dans ton modèle Runpod."
  else
    echo "   Installation de PyTorch CUDA 13 impossible : on garde la version de l'image (calcul de repli, plus lent)."
  fi
elif [ -n "$TORCH_CUDA" ] && [ "${TORCH_CUDA%%.*}" -lt 13 ]; then
  echo "   ATTENTION : pilote trop ancien pour CUDA 13 (CUDA ${PILOTE_CUDA:-?}) : noyaux optimisés de ComfyUI indisponibles."
  echo "   Choisis un Pod avec le filtre « CUDA 13.0 » au déploiement."
fi
# torchvision et torchaudio doivent être compilés pour la MÊME version de PyTorch et de CUDA : sinon ComfyUI s'arrête au
# démarrage (« operator torchvision::nms does not exist »). Ça arrive quand l'image n'en fournit pas et que pip prend
# ceux de PyPI (compilés pour un autre CUDA). Vérifié à chaque démarrage, réparé depuis le dépôt PyTorch du bon CUDA.
verifier_torchvision() {
  python -c "import torch, torchvision; from torchvision.ops import nms; nms(torch.zeros(1,4), torch.zeros(1), 0.5)" >/dev/null 2>&1
}
raison_torchvision() {   # dernière ligne de l'erreur, pour le journal
  python -c "import torch, torchvision; from torchvision.ops import nms; nms(torch.zeros(1,4), torch.zeros(1), 0.5)" 2>&1 | tail -n 1 | cut -c1-200
}
if ! verifier_torchvision; then
  echo "   Problème : $(raison_torchvision)"
  read -r TORCH_VER TV_VER TA_VER TORCH_IDX < <(python -c "
import torch
v = torch.__version__.split('+')[0]; M, m, p = (v.split('.') + ['0', '0'])[:3]; m = int(m)
print(v, f'0.{m + 15}.{p}', v if m < 12 else '2.11.0', 'cu' + (torch.version.cuda or '').replace('.', ''))" 2>/dev/null || echo "? ? ? ?")
  URL_IDX="https://download.pytorch.org/whl/${TORCH_IDX}"
  echo "   PyTorch ${TORCH_VER} (${TORCH_IDX}) : installation de torchvision ${TV_VER} et torchaudio ${TA_VER} correspondants…"
  if [ "$TV_VER" != "?" ]; then
    pip install --quiet --no-deps --force-reinstall "torchvision==${TV_VER}" "torchaudio==${TA_VER}" --index-url "$URL_IDX" 2>&1 | tail -n 3 || true
  fi
  if ! verifier_torchvision && [ "$TV_VER" != "?" ]; then
    # Repli : les trois paquets ensemble, depuis le même dépôt (dans l'environnement de ComfyUI, l'image n'est pas modifiée)
    echo "   Toujours incompatible ($(raison_torchvision)) : installation de PyTorch, torchvision et torchaudio ensemble…"
    pip install --quiet --force-reinstall "torch==${TORCH_VER}" "torchvision==${TV_VER}" "torchaudio==${TA_VER}" --index-url "$URL_IDX" 2>&1 | tail -n 5 || true
  fi
  if verifier_torchvision; then
    echo "   torchvision : compatible avec PyTorch"
  else
    echo "ARRÊT : torchvision ne correspond pas à PyTorch et n'a pas pu être réparé : $(raison_torchvision)"; exit 1
  fi
fi
# torchaudio : utile aux nœuds audio de ComfyUI (pas indispensable au démarrage) ; signalé s'il ne se charge pas
python -c "import torchaudio" >/dev/null 2>&1 || echo "   (torchaudio ne se charge pas : $(python -c 'import torchaudio' 2>&1 | tail -n 1 | cut -c1-160))"
pip freeze | grep -iE '^(torch|torchvision|torchaudio)==' > /root/torch-verrou.txt
pip install --quiet -r /workspace/ComfyUI/requirements.txt -c /root/torch-verrou.txt
# comfy-kitchen avec cuBLAS (calcul nvfp4 sur Blackwell), même version que celle demandée par ComfyUI ; PyTorch inchangé
CK_VERSION=$(grep -iE '^comfy[-_]kitchen==' /workspace/ComfyUI/requirements.txt | head -n1 | cut -d= -f3 || true)
if [ -n "$CK_VERSION" ]; then
  pip install --quiet "comfy-kitchen[cublas]==${CK_VERSION}" -c /root/torch-verrou.txt \
    || echo "   (extension cuBLAS de comfy-kitchen non installée : nvfp4 par calcul de repli)"
fi
python -c "import torch; print('PyTorch :', torch.__version__, '| GPU OK :', torch.cuda.is_available())"
if ! python -c "import torch, sys; sys.exit(0 if torch.cuda.is_available() else 1)" 2>/dev/null; then
  PILOTE_CUDA=$(nvidia-smi 2>/dev/null | grep -o 'CUDA Version: [0-9.]*' | grep -o '[0-9.]*$' || true)
  echo "   ATTENTION : PyTorch ne voit pas la carte (pilote de la machine : CUDA ${PILOTE_CUDA:-inconnu})."
  echo "   L'image du Pod demande CUDA 13 : termine ce Pod et redéploie-le avec le filtre « CUDA 13.0 »."
fi

echo "==> 4/6 Commande « civitai »"
install -m 755 /root/civitai.py /usr/local/bin/civitai
M=/workspace/ComfyUI/models
mkdir -p "$M/checkpoints" "$M/diffusion_models" "$M/text_encoders" "$M/vae" "$M/loras" \
         "$M/controlnet" "$M/embeddings" "$M/upscale_models"

# Extensions ComfyUI (Krea2Edit, Ostris Edit pour ReID, AnyPaint) : livrées dans le paquet du Pod, relues
# (calcul pur : aucun accès réseau, aucune écriture de fichier), vérifiées une à une par leur empreinte.
CN=/workspace/ComfyUI/custom_nodes
for EXTD in comfyui-krea2edit comfyui-krea2-ostris-edit krea2-anypaint; do
  rm -rf "$CN/$EXTD"
  if [ -d /root/extensions/$EXTD ] && (cd /root/extensions && grep " $EXTD/" SHA256SUMS | sha256sum -c --quiet -); then
    mkdir -p "$CN/$EXTD"
    cp /root/extensions/$EXTD/* "$CN/$EXTD/"
    echo "   Extension $EXTD : installée (empreintes vérifiées)"
  else
    echo "   Extension $EXTD : absente ou empreinte incorrecte, non installée"
  fi
done

echo "==> 5/6 GPU détecté"
VRAM=$(nvidia-smi --query-gpu=memory.total --format=csv,noheader,nounits | head -n1)
NOM=$(nvidia-smi --query-gpu=name --format=csv,noheader | head -n1)
if [ "${VRAM:-0}" -ge 40000 ]; then PROFIL=6000; else PROFIL=4090; fi
echo "   ${NOM} (${VRAM} MiB) -> profil ${PROFIL}"
# PyTorch et la carte : la carte doit figurer dans les architectures compilées (sinon kernels génériques, plus lents)
python - <<'PY' || true
import torch
cc = torch.cuda.get_device_capability() if torch.cuda.is_available() else None
archs = torch.cuda.get_arch_list() if torch.cuda.is_available() else []
print(f"   PyTorch {torch.__version__} (CUDA {torch.version.cuda}) · carte sm_{cc[0]}{cc[1]}" if cc else "   PyTorch : pas de carte visible")
if cc:
    sm = [a for a in archs if a.startswith("sm_")]
    # un binaire sm_X0 tourne sur toute carte sm_Xy de même génération (ex. sm_100 sur une B300 sm_103)
    ok = any(a[3:-1] == str(cc[0]) and int(a[-1]) <= cc[1] for a in sm)
    print("   Architectures compilées : " + " ".join(sm) + ("  (compatibles avec cette carte)" if ok else
          f"  → aucune pour sm_{cc[0]}{cc[1]} : calcul par compilation à la volée, plus lent"))
    try:
        import comfy_kitchen as ck
        ok_ck = int(str(torch.version.cuda).split(".")[0]) >= 13
        etat = ck.list_backends()
        dispo = [k for k, v in etat.items() if isinstance(v, dict) and v.get("available") and not v.get("disabled")]
        raison = (etat.get("cuda") or {}).get("unavailable_reason") if isinstance(etat.get("cuda"), dict) else None
        print("   Noyaux optimisés comfy-kitchen " + getattr(ck, "__version__", "") + " : " +
              (("actifs (CUDA 13)" if "cuda" in dispo else f"noyau CUDA indisponible ({raison or ', '.join(dispo)})")
               if ok_ck else "INACTIFS (PyTorch CUDA 12 : calcul de repli, plus lent)"))
    except Exception as e:
        print(f"   comfy-kitchen : vérification impossible ({type(e).__name__})")
    if cc == (10, 3):
        print("   B300 : int8 très lent sur cette carte ; Studio n'utilise et n'installe que du bf16 / fp16 / fp8 / nvfp4")
PY

echo "==> 6/6 Vérification"
[ "$(readlink -f /root/prive)" = "$ZONE" ] && [ "$(stat -f -c %T /root/prive/)" = "tmpfs" ] \
  && echo "   Zone privée : ACTIVE (mémoire vive)" || { echo "ARRÊT : zone privée non active."; exit 1; }

echo ""
echo "Installation terminée."
echo "  - Clé Civitai pour la session : civitai login"
echo "  - Contrôler le disque         : civitai audit"
